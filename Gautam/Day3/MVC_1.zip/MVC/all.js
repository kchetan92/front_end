function PageController() {
    this.cManager = new ContactManager;
    this.cView = new ContactsView;
                function updateContacts(contactsJSON) {
        this.cManager.addContactsFromJSON(contactsJSON);
        this.cView.render(this.cManager.contacts);
    }
    this.cView.init(this);
                this.fetchContactsFromServer(updateContacts.bind(this));
                
}

PageController.prototype.fetchContactsFromServer = function(callback) {
    // Make the call to server
    // After fetching the data, call the callback provided with the data
    // as its argument
    callback('[{"name": "Gautham", "place": "Bangalore"}, {"name": "Raghav", "place": "Mumbai"}]');
}

PageController.prototype.contactAdded = function(callback) {
   this.cManager.addContact(new Contact(this.cView.getContactsFromForm()));
   this.cView.render(this.cManager.contacts);
   this.cView.clearForm();
}


function ContactsView() {
this.init=function(ctrl){
                this.addcontact=document.getElementById('addcontact');
                this.name=document.getElementById('name');
                this.place=document.getElementById('place');
                this.addcontact.addEventListener('submit',function(event){
                event.preventDefault();
                //This could be better with Observers - we should decouple this
                // and make this an event listener
                ctrl.contactAdded();
                });

}
}

ContactsView.prototype.getContactsFromForm=function(){
return { name : this.name.value, place: this.place.value};
}

ContactsView.prototype.render = function(contacts) {
    var table = document.getElementById('contactstable');
                table.innerHTML='';
    contacts.forEach(function(contact) {
        var row = table.insertRow(-1);
        row.insertCell(0).innerHTML = contact.name;
        row.insertCell(1).innerHTML = contact.place;
    });
}

ContactsView.prototype.clearForm= function() {
                this.name.value='';
                this.place.value='';
                this.name.focus();
}

function ContactManager() {
    this.contacts = [];
}

function Contact(contact) {
    for(var key in contact) {
        this[key] = contact[key];
    }
}

ContactManager.prototype.addContact = function(contact) {
    this.contacts.push(contact);
}

ContactManager.prototype.addContactsFromJSON = function(jsonString) {
    var contactsObj = JSON.parse(jsonString);
    var that = this;
    contactsObj.forEach(function(contact) {
        that.addContact(new Contact(contact));
    });
}


window.addEventListener('load', function() { // We have hidden PageController
    new PageController();
});
                







